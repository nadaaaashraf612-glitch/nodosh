"use client";

import { Fragment } from "react";
import { motion } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { AccentButton, Kicker, PageMeta } from "../components/ui";
import { DigitalGlass } from "../components/glass/DigitalGlass";
import { CodeIcon, LightbulbIcon, PenToolIcon } from "../components/icons";
import { useLanguage } from "../i18n/LanguageContext";

const impactIcons = [LightbulbIcon, PenToolIcon, CodeIcon];

/**
 * Three "not enough alone" statements that fade in side by side, then the answer.
 * Everything reveals with the normal scroll — quick, light, and nobody has to stand still.
 */
function ImpactStatement() {
  const { t } = useLanguage();
  const ease = [0.16, 1, 0.3, 1] as const;

  return (
    <div className="relative z-10 mx-auto w-full max-w-6xl">
      <div className="grid grid-cols-1 items-start gap-10 md:grid-cols-[1fr_auto_1fr_auto_1fr] md:gap-6">
        {t.impact.lines.map((line, i) => {
          const Icon = impactIcons[i];
          return (
            <Fragment key={line}>
              {i > 0 && (
                <motion.span
                  aria-hidden
                  initial={{ opacity: 0, scale: 0.6 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.4, delay: i * 0.12, ease }}
                  className="mx-auto font-display text-3xl text-black/30 md:mt-6"
                >
                  +
                </motion.span>
              )}
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.55, delay: i * 0.12, ease }}
                className="text-center"
              >
                <motion.span
                  className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-black/20 text-black [&_svg]:h-6 [&_svg]:w-6"
                  animate={{ y: [0, -4, 0] }}
                  transition={{ duration: 3.2, delay: i * 0.4, repeat: Infinity, ease: "easeInOut" }}
                >
                  <Icon />
                </motion.span>
                <p className="mt-6 font-display text-2xl leading-snug text-black/80 sm:text-3xl">{line}</p>
                <motion.span
                  aria-hidden
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.6, delay: 0.25 + i * 0.12, ease }}
                  className="mx-auto mt-6 block h-px w-16 bg-black/25"
                />
              </motion.div>
            </Fragment>
          );
        })}
      </div>

      <div className="mt-16 text-center sm:mt-20">
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.5, delay: 0.1, ease }}
          className="font-display text-xl text-black/70 sm:text-3xl"
        >
          {t.impact.joiner}
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.6, delay: 0.25, ease }}
          className="relative mt-5 inline-block font-display text-4xl font-semibold leading-tight tracking-tight text-black sm:text-6xl lg:text-7xl"
        >
          {t.impact.final}
          <motion.span
            aria-hidden
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.8, delay: 0.6, ease }}
            className="absolute -bottom-2 start-0 block h-[3px] w-full origin-center rounded-full bg-black"
          />
        </motion.h2>
      </div>
    </div>
  );
}

export function Closing() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "contact");

  return (
    <>
      <section
        id="impact"
        className="relative flex flex-col items-center justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
      >
        <BlurShapes tone="light" seed={2} />
        <ImpactStatement />
      </section>

      <section
        id="closing"
        className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
      >
        <BlurShapes tone="light" seed={3} />

        <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-6 lg:grid-cols-2 lg:gap-12">
          <Reveal className="order-2 lg:order-1">
            <Kicker>{t.cta.kicker}</Kicker>
            <h2 className="mt-8 font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
              {t.cta.heading}
            </h2>
            <p className="mt-6 max-w-xl text-sm leading-relaxed text-black/65 sm:text-base">{t.cta.copy}</p>
            <div className="mt-10">
              <AccentButton href="#contact" tone="dark">
                {t.cta.button}
              </AccentButton>
            </div>
          </Reveal>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative order-1 mx-auto aspect-[1.1/1] w-full max-w-[600px] lg:order-2"
          >
            <DigitalGlass className="absolute inset-0" />
          </motion.div>
        </div>

        <PageMeta index={String(idx).padStart(2, "0")} label={t.sectionIndex[idx].label} />
      </section>
    </>
  );
}
