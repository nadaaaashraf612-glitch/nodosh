"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Reveal } from "../components/Reveal";
import { BlurShapes } from "../components/BlurShapes";
import { GlowOrb, Kicker, PageMeta } from "../components/ui";
import { WhyArt } from "../components/WhyArt";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * "What sets us apart" — a scroll-driven story.
 * A sticky stage on one side keeps the heading and a live counter; on the other side the five reasons
 * scroll past as tall panels. The panel in focus lights up, the others recede.
 */
export function Why() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "why");
  const items = t.why.items;
  const [active, setActive] = useState(0);
  const panels = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(Number((e.target as HTMLElement).dataset.i));
        });
      },
      { rootMargin: "-42% 0px -42% 0px", threshold: 0 }
    );
    panels.current.forEach((el) => el && obs.observe(el));
    return () => obs.disconnect();
  }, [items.length]);

  const goTo = (i: number) =>
    panels.current[i]?.scrollIntoView({ behavior: "smooth", block: "center" });

  const total = String(items.length).padStart(2, "0");

  return (
    <section
      id="why"
      className="relative overflow-clip bg-black px-6 pb-32 pt-28 text-white isolate sm:px-10 lg:px-16"
    >
      <BlurShapes tone="dark" seed={18} />
      <GlowOrb tone="dark" className="start-1/4 bottom-0 h-96 w-96" />
      <div className="grain absolute inset-0 opacity-50" />

      <div className="relative z-10 grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:gap-20">
        {/* ───────── sticky stage ───────── */}
        <div className="lg:sticky lg:top-28 lg:flex lg:h-[calc(100vh-14rem)] lg:min-h-[480px] lg:flex-col lg:justify-between lg:self-start">
          <Reveal>
            <Kicker tone="light">{t.why.kicker}</Kicker>
            <h2 className="mt-8 max-w-xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
              {t.why.heading}
            </h2>
          </Reveal>

          {/* live counter + rail (desktop) */}
          <div className="mt-12 hidden items-end gap-8 lg:flex">
            <div className="relative h-44 w-px shrink-0 bg-white/15">
              <motion.span
                className="absolute inset-x-0 top-0 block w-px bg-white"
                animate={{ height: `${((active + 1) / items.length) * 100}%` }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              />
              {items.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => goTo(i)}
                  aria-label={String(i + 1)}
                  className="absolute -start-[5px] block h-[11px] w-[11px] rounded-full border border-white/50 transition-colors"
                  style={{
                    top: `calc(${(i / (items.length - 1)) * 100}% - 5px)`,
                    background: i <= active ? "#fff" : "#000",
                  }}
                />
              ))}
            </div>

            <div dir="ltr" className="flex items-baseline gap-3 leading-none">
              <div className="relative h-[8.5rem] w-[11rem] overflow-hidden">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={active}
                    initial={{ y: "70%", opacity: 0 }}
                    animate={{ y: "0%", opacity: 1 }}
                    exit={{ y: "-70%", opacity: 0 }}
                    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute inset-0 flex items-center font-display text-[8rem] font-medium leading-none tracking-tight"
                  >
                    {String(active + 1).padStart(2, "0")}
                  </motion.span>
                </AnimatePresence>
              </div>
              <span className="font-display text-xl text-white/40">/ {total}</span>
            </div>
          </div>
        </div>

        {/* ───────── scrolling reasons ───────── */}
        <ol className="flex flex-col gap-6 lg:gap-[14vh] lg:pb-[6vh] lg:pt-[8vh]">
          {items.map((item, i) => {
            const on = i === active;
            const [lead, ...rest] = item.title.split(" ");
            return (
              <li
                key={item.title}
                data-i={i}
                ref={(el) => {
                  panels.current[i] = el;
                }}
              >
                <motion.article
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                  className="relative overflow-hidden rounded-[2rem] border p-6 transition-[border-color,background-color,opacity,transform] duration-700 sm:p-9"
                  style={{
                    borderColor: on ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.1)",
                    background: on
                      ? "linear-gradient(160deg, rgba(255,255,255,0.1), rgba(255,255,255,0.02))"
                      : "rgba(255,255,255,0.02)",
                    opacity: on ? 1 : 0.5,
                    transform: on ? "scale(1)" : "scale(0.975)",
                  }}
                >
                  {/* spotlight */}
                  <span
                    aria-hidden
                    className="pointer-events-none absolute -end-24 -top-24 h-64 w-64 rounded-full transition-opacity duration-700"
                    style={{
                      opacity: on ? 1 : 0,
                      background: "radial-gradient(circle, rgba(255,255,255,0.16), transparent 70%)",
                    }}
                  />

                  <div className="relative flex items-start justify-between gap-6">
                    <span
                      dir="ltr"
                      className="font-display text-7xl font-medium leading-none sm:text-8xl"
                      style={{
                        color: on ? "#fff" : "transparent",
                        WebkitTextStroke: on ? "0px transparent" : "1px rgba(255,255,255,0.45)",
                        transition: "color .6s ease",
                      }}
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <WhyArt index={i} className="h-24 w-40 shrink-0 sm:h-28 sm:w-48" />
                  </div>

                  <h3 className="relative mt-8 font-display text-2xl font-semibold leading-snug tracking-tight sm:text-3xl">
                    <span className="me-2 text-white/45">{lead}</span>
                    {rest.join(" ")}
                  </h3>
                  <p className="relative mt-4 max-w-xl text-sm leading-relaxed text-white/65 sm:text-base">
                    {item.copy}
                  </p>
                </motion.article>
              </li>
            );
          })}
        </ol>
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} tone="light" />
    </section>
  );
}
