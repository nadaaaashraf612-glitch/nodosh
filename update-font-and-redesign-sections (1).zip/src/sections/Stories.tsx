"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";
import { useLanguage } from "../i18n/LanguageContext";

type Milestone = { tag: string; title: string; copy: string };

/**
 * A scrolling journey: one thin line that fills as the reader moves down the page,
 * with each chapter lighting its own node as it arrives. Nothing pins, nothing waits.
 */
function Chapter({ item, i, total }: { item: Milestone; i: number; total: number }) {
  const { dir } = useLanguage();
  const rtl = dir === "rtl";
  const ref = useRef<HTMLLIElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 62%", "end 62%"] });
  const fill = useTransform(scrollYProgress, [0, 1], [0, 1]);
  const even = i % 2 === 0;
  const last = i === total - 1;
  // chapters slide in from their own side (towards the centre line)
  const fromX = (even ? 1 : -1) * (rtl ? -1 : 1) * -36;

  return (
    <li
      ref={ref}
      className="relative grid grid-cols-[3rem_minmax(0,1fr)] md:grid-cols-[minmax(0,1fr)_4rem_minmax(0,1fr)]"
    >
      {/* line + node */}
      <div className="relative col-start-1 row-start-1 flex justify-center md:col-start-2">
        <span aria-hidden className="absolute inset-y-0 w-px bg-black/12" style={last ? { bottom: "auto", height: "2.75rem" } : undefined} />
        <motion.span
          aria-hidden
          className="absolute top-0 w-px origin-top bg-black"
          style={{ scaleY: fill, ...(last ? { height: "2.75rem" } : { bottom: 0 }) }}
        />
        <motion.span
          aria-hidden
          initial={{ scale: 0.6, backgroundColor: "#fafaf8" }}
          whileInView={{ scale: 1, backgroundColor: "#0a0a0a" }}
          viewport={{ once: true, margin: "0px 0px -38% 0px" }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 mt-9 block h-4 w-4 rounded-full border border-black ring-[6px] ring-[#fafaf8]"
        />
      </div>

      {/* content */}
      <motion.div
        initial={{ opacity: 0, x: fromX }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
        className={`col-start-2 row-start-1 pb-14 md:pb-20 ${even ? "md:col-start-1 md:text-end" : "md:col-start-3 md:text-start"}`}
      >
        <div className={`flex items-baseline gap-4 ${even ? "md:flex-row-reverse" : ""}`}>
          <span
            dir="ltr"
            className="font-display text-6xl font-semibold leading-none tracking-tight text-black sm:text-7xl"
          >
            {item.tag}
          </span>
          <span aria-hidden className="h-px flex-1 bg-black/15" />
        </div>
        <h3 className="mt-5 font-display text-2xl font-semibold tracking-tight sm:text-3xl">{item.title}</h3>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-black/65 sm:text-base md:inline-block">{item.copy}</p>
      </motion.div>
    </li>
  );
}

export function Stories() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "stories");
  const items = t.stories.items as Milestone[];

  return (
    <section id="stories" className="relative overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16">
      <BlurShapes tone="light" seed={3} />

      <Reveal>
        <Kicker>{t.stories.kicker}</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
          {t.stories.heading}
        </h2>
      </Reveal>

      <ol className="relative z-10 mx-auto mt-16 max-w-5xl">
        {items.map((item, i) => (
          <Chapter key={item.title} item={item} i={i} total={items.length} />
        ))}
      </ol>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} />
    </section>
  );
}
