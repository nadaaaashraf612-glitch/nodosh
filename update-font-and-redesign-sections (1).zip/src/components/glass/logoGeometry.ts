import * as THREE from "three";
import { SVGLoader } from "three/addons/loaders/SVGLoader.js";
import { ICON_DOT, ICON_PATH } from "./kit";

/** The full PUIUX mark as 3D geometry: an extruded cradle plus a true sphere for the dot (SVG units). */
export function buildLogoGeometry() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg"><path d="${ICON_PATH}"/></svg>`;
  const data = new SVGLoader().parse(svg);
  const shapes = data.paths[0].toShapes();

  const body = new THREE.ExtrudeGeometry(shapes, {
    depth: 84,
    curveSegments: 40,
    bevelEnabled: true,
    bevelThickness: 26,
    bevelSize: 18,
    bevelSegments: 10,
  });

  // the "dot" becomes a true sphere sitting inside the cradle
  const dot = new THREE.SphereGeometry(ICON_DOT.rx * 1.02, 64, 48);

  body.scale(1, -1, 1);
  body.computeBoundingBox();
  const c = new THREE.Vector3();
  body.boundingBox!.getCenter(c);
  body.translate(-c.x, -c.y, -c.z);
  dot.translate(ICON_DOT.cx - c.x, -ICON_DOT.cy - c.y, 0);
  body.computeVertexNormals();

  const width = body.boundingBox!.max.x - body.boundingBox!.min.x;
  return { body, dot, width };
}
